#!/bin/bash
# build the extension as .zip to site directory (public/)
cd ./extension
zip -r bin/MemeMachine.zip ./*